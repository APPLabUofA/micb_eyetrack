## Getting started with samples

In order to get started make sure you have Tobii EyeTracking Core Bundle installed.
Check that you have an icon with two moving white dots in your tray. 

If not, please run Tobii Eye Tracking application. And do not forget to calibrate! :)

If you do not have Tobii Eye Tracking application do not worry, just head to our 
[website](http://developer.tobii.com/eyex-setup/) and download it.

If you experience any issues, we are sure our [support](https://help.tobii.com/hc/en-us) will help you. 





