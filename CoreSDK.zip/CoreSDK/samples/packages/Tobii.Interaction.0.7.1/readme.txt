Welcome to Tobii Core SDK
=========================

We have a documentation which you can find here: https://tobiitechnology.github.io/TobiiCoreSDK/

And we have samples here: https://github.com/TobiiTechnology/TobiiCoreSDK/tree/master/samples


Release notes:
==========================

* What's new in version 0.7.1:
	- public beta release

